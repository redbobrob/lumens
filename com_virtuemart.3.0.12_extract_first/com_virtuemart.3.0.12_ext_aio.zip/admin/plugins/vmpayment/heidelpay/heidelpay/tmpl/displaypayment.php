<?php  defined('_JEXEC') or die();
/**
 * @version $Id:$
 * Heidelpay credit card plugin
 *
 * @author Heidelberger Paymenrt GmbH <Jens Richter>
 * @package VirtueMart
 * @copyright Copyright (c) 2004 - 2012 VirtueMart Team. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
?>

<iframe id="payment_frame" width="500px" height="650px" frameborder="0"
		border="0" src="<?php echo $viewData['response'] ?>"
		style="width: 450px; height: 650px; border: 0px solid #000;"></iframe></center>


